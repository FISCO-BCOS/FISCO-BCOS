/*
 * @file: gadget.hpp
 * @author: jimmyshi 
 * @date: 4th May 2018
 * @copyright: MIT license (see LICENSE file)
 */


#ifndef ZKG_GADGET_H_
#define ZKG_GADGET_H_

#include "gov.tcc"
#include "tx.tcc"

#endif