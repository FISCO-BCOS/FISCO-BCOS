package com.example.delivery.raw;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Address;
import org.fisco.bcos.sdk.abi.datatypes.Bool;
import org.fisco.bcos.sdk.abi.datatypes.Event;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.generated.Uint256;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple2;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple4;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.eventsub.EventCallback;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class StorageData extends Contract {
    public static final String[] BINARY_ARRAY = {"608060405234801561001057600080fd5b5061032b806100206000396000f300608060405260043610610062576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff168063058d3fd9146100675780632143ef681461009257806331c02c11146101405780637278ee97146101ca575b600080fd5b34801561007357600080fd5b5061007c610225565b6040518082815260200191505060405180910390f35b34801561009e57600080fd5b506100bd6004803603810190808035906020019092919050505061022b565b604051808581526020018473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200194505050505060405180910390f35b34801561014c57600080fd5b50610181600480360381019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919050505061029b565b604051808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018281526020019250505060405180910390f35b3480156101d657600080fd5b5061020b600480360381019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291905050506102df565b604051808215151515815260200191505060405180910390f35b60005481565b60036020528060005260406000206000915090508060000154908060010160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16908060020160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16908060030154905084565b60026020528060005260406000206000915090508060000160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16908060010154905082565b60016020528060005260406000206000915054906101000a900460ff16815600a165627a7a7230582019111cb2069c101ea0710510f43c9c2811d9aeb9eb05a1b947ed6459071a0f870029"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":true,\"inputs\":[],\"name\":\"RecordCount\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"RecordMap\",\"outputs\":[{\"name\":\"record_id\",\"type\":\"uint256\"},{\"name\":\"c_address\",\"type\":\"address\"},{\"name\":\"u_address\",\"type\":\"address\"},{\"name\":\"sign_time\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"UserMap\",\"outputs\":[{\"name\":\"u_address\",\"type\":\"address\"},{\"name\":\"role\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"UserIsSignStatus\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"_userAddress\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"_role\",\"type\":\"uint256\"}],\"name\":\"Registered\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"_userAddress\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"_isSign\",\"type\":\"bool\"}],\"name\":\"Signed\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"_userAddress\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"_time\",\"type\":\"uint256\"}],\"name\":\"Refusal\",\"type\":\"event\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC_RECORDCOUNT = "RecordCount";

    public static final String FUNC_RECORDMAP = "RecordMap";

    public static final String FUNC_USERMAP = "UserMap";

    public static final String FUNC_USERISSIGNSTATUS = "UserIsSignStatus";

    public static final Event REGISTERED_EVENT = new Event("Registered", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Uint256>(true) {}));
    ;

    public static final Event SIGNED_EVENT = new Event("Signed", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Bool>(true) {}));
    ;

    public static final Event REFUSAL_EVENT = new Event("Refusal", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Uint256>(true) {}));
    ;

    protected StorageData(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public BigInteger RecordCount() throws ContractException {
        final Function function = new Function(FUNC_RECORDCOUNT, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeCallWithSingleValueReturn(function, BigInteger.class);
    }

    public Tuple4<BigInteger, String, String, BigInteger> RecordMap(BigInteger param0) throws ContractException {
        final Function function = new Function(FUNC_RECORDMAP, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Address>() {}, new TypeReference<Address>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple4<BigInteger, String, String, BigInteger>(
                (BigInteger) results.get(0).getValue(), 
                (String) results.get(1).getValue(), 
                (String) results.get(2).getValue(), 
                (BigInteger) results.get(3).getValue());
    }

    public Tuple2<String, BigInteger> UserMap(String param0) throws ContractException {
        final Function function = new Function(FUNC_USERMAP, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple2<String, BigInteger>(
                (String) results.get(0).getValue(), 
                (BigInteger) results.get(1).getValue());
    }

    public Boolean UserIsSignStatus(String param0) throws ContractException {
        final Function function = new Function(FUNC_USERISSIGNSTATUS, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeCallWithSingleValueReturn(function, Boolean.class);
    }

    public List<RegisteredEventResponse> getRegisteredEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(REGISTERED_EVENT, transactionReceipt);
        ArrayList<RegisteredEventResponse> responses = new ArrayList<RegisteredEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            RegisteredEventResponse typedResponse = new RegisteredEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._userAddress = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._role = (BigInteger) eventValues.getIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeRegisteredEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(REGISTERED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeRegisteredEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(REGISTERED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public List<SignedEventResponse> getSignedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(SIGNED_EVENT, transactionReceipt);
        ArrayList<SignedEventResponse> responses = new ArrayList<SignedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            SignedEventResponse typedResponse = new SignedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._userAddress = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._isSign = (Boolean) eventValues.getIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeSignedEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(SIGNED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeSignedEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(SIGNED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public List<RefusalEventResponse> getRefusalEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(REFUSAL_EVENT, transactionReceipt);
        ArrayList<RefusalEventResponse> responses = new ArrayList<RefusalEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            RefusalEventResponse typedResponse = new RefusalEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._userAddress = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._time = (BigInteger) eventValues.getIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeRefusalEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(REFUSAL_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeRefusalEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(REFUSAL_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public static StorageData load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new StorageData(contractAddress, client, credential);
    }

    public static StorageData deploy(Client client, CryptoKeyPair credential) throws ContractException {
        return deploy(StorageData.class, client, credential, getBinary(client.getCryptoSuite()), "");
    }

    public static class RegisteredEventResponse {
        public TransactionReceipt.Logs log;

        public String _userAddress;

        public BigInteger _role;
    }

    public static class SignedEventResponse {
        public TransactionReceipt.Logs log;

        public String _userAddress;

        public Boolean _isSign;
    }

    public static class RefusalEventResponse {
        public TransactionReceipt.Logs log;

        public String _userAddress;

        public BigInteger _time;
    }
}
