package com.example.delivery.service;

import com.example.delivery.model.bo.DeliveryAfterSalesInputBO;
import com.example.delivery.model.bo.DeliveryCourierRegisterInputBO;
import com.example.delivery.model.bo.DeliveryCourierToUserSignInputBO;
import com.example.delivery.model.bo.DeliveryRecordMapInputBO;
import com.example.delivery.model.bo.DeliveryRegisterParallelFunctionInputBO;
import com.example.delivery.model.bo.DeliverySignRecordListInputBO;
import com.example.delivery.model.bo.DeliveryUnregisterParallelFunctionInputBO;
import com.example.delivery.model.bo.DeliveryUserIsClaimStatusInputBO;
import com.example.delivery.model.bo.DeliveryUserIsSignStatusInputBO;
import com.example.delivery.model.bo.DeliveryUserMapInputBO;
import com.example.delivery.model.bo.DeliveryUserRegisterInputBO;
import java.lang.Exception;
import java.lang.String;
import java.util.Arrays;
import javax.annotation.PostConstruct;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.CallResponse;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@NoArgsConstructor
@Data
public class DeliveryService {
  public static final String ABI = com.example.delivery.utils.IOUtil.readResourceAsString("abi/Delivery.abi");

  public static final String BINARY = com.example.delivery.utils.IOUtil.readResourceAsString("bin/ecc/Delivery.bin");

  public static final String SM_BINARY = com.example.delivery.utils.IOUtil.readResourceAsString("bin/sm/Delivery.bin");

  @Value("${system.contract.deliveryAddress}")
  private String address;

  @Autowired
  private Client client;

  AssembleTransactionProcessor txProcessor;

  @PostConstruct
  public void init() throws Exception {
    this.txProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(this.client, this.client.getCryptoSuite().getCryptoKeyPair());
  }

  public TransactionResponse registerParallelFunction(DeliveryRegisterParallelFunctionInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "registerParallelFunction", input.toArgs());
  }

  public TransactionResponse enableParallel() throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "enableParallel", Arrays.asList());
  }

  public CallResponse UserIsClaimStatus(DeliveryUserIsClaimStatusInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "UserIsClaimStatus", input.toArgs());
  }

  public TransactionResponse courierToUserSign(DeliveryCourierToUserSignInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "courierToUserSign", input.toArgs());
  }

  public CallResponse UserMap(DeliveryUserMapInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "UserMap", input.toArgs());
  }

  public TransactionResponse courierRegister(DeliveryCourierRegisterInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "courierRegister", input.toArgs());
  }

  public CallResponse RecordCount() throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "RecordCount", Arrays.asList());
  }

  public TransactionResponse disableParallel() throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "disableParallel", Arrays.asList());
  }

  public TransactionResponse selectSignRecordList() throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "selectSignRecordList", Arrays.asList());
  }

  public CallResponse UserIsSignStatus(DeliveryUserIsSignStatusInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "UserIsSignStatus", input.toArgs());
  }

  public CallResponse RecordMap(DeliveryRecordMapInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "RecordMap", input.toArgs());
  }

  public TransactionResponse unregisterParallelFunction(DeliveryUnregisterParallelFunctionInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "unregisterParallelFunction", input.toArgs());
  }

  public CallResponse SignRecordList(DeliverySignRecordListInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "SignRecordList", input.toArgs());
  }

  public TransactionResponse afterSales(DeliveryAfterSalesInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "afterSales", input.toArgs());
  }

  public TransactionResponse userRegister(DeliveryUserRegisterInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "userRegister", input.toArgs());
  }
}
