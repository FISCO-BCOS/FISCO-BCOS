package com.example.delivery.service;

import com.example.delivery.model.bo.StorageDataRecordMapInputBO;
import com.example.delivery.model.bo.StorageDataUserIsSignStatusInputBO;
import com.example.delivery.model.bo.StorageDataUserMapInputBO;
import java.lang.Exception;
import java.lang.String;
import java.util.Arrays;
import javax.annotation.PostConstruct;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.CallResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@NoArgsConstructor
@Data
public class StorageDataService {
  public static final String ABI = com.example.delivery.utils.IOUtil.readResourceAsString("abi/StorageData.abi");

  public static final String BINARY = com.example.delivery.utils.IOUtil.readResourceAsString("bin/ecc/StorageData.bin");

  public static final String SM_BINARY = com.example.delivery.utils.IOUtil.readResourceAsString("bin/sm/StorageData.bin");

  @Value("${system.contract.storageDataAddress}")
  private String address;

  @Autowired
  private Client client;

  AssembleTransactionProcessor txProcessor;

  @PostConstruct
  public void init() throws Exception {
    this.txProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(this.client, this.client.getCryptoSuite().getCryptoKeyPair());
  }

  public CallResponse UserMap(StorageDataUserMapInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "UserMap", input.toArgs());
  }

  public CallResponse RecordCount() throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "RecordCount", Arrays.asList());
  }

  public CallResponse UserIsSignStatus(StorageDataUserIsSignStatusInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "UserIsSignStatus", input.toArgs());
  }

  public CallResponse RecordMap(StorageDataRecordMapInputBO input) throws Exception {
    return this.txProcessor.sendCall(this.client.getCryptoSuite().getCryptoKeyPair().getAddress(), this.address, ABI, "RecordMap", input.toArgs());
  }
}
