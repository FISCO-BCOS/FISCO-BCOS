package com.example.delivery.controller;


import com.example.delivery.model.bo.DeliveryAfterSalesInputBO;
import com.example.delivery.model.bo.DeliveryCourierRegisterInputBO;
import com.example.delivery.model.bo.DeliveryCourierToUserSignInputBO;
import com.example.delivery.model.bo.DeliveryUserRegisterInputBO;
import com.example.delivery.service.DeliveryService;
import lombok.extern.slf4j.Slf4j;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.model.CryptoType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@Slf4j
@RestController
@RequestMapping("/delivery")
public class DeliveryController {

    @Autowired
    private DeliveryService deliveryService;

    @GetMapping("/sign")
    public void courierToUserSign(){
        // 开启允许并行执行
        try
        {
            deliveryService.enableParallel();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // 直接批量注册用户和快递员
        ArrayList<String> userList = initUserAddress();
        ArrayList<String> courierList = initUserAddress();
        InitUserAndCourier(userList, courierList);


        ExecutorService threadPool = Executors.newFixedThreadPool(10); // 设置线程池大小

        for (int i = 0; i < courierList.size(); i++) {
            final int currentIndex = i;
            threadPool.execute(() -> {
                try {
                    DeliveryCourierToUserSignInputBO signInputBO = new DeliveryCourierToUserSignInputBO();
                    signInputBO.set_isSign(BigInteger.valueOf(0));
                    signInputBO.set_from(courierList.get(currentIndex));
                    signInputBO.set_to(userList.get(currentIndex));

                    long startTime = System.currentTimeMillis();
                    deliveryService.courierToUserSign(signInputBO);
                    long endTime = System.currentTimeMillis();
                    log.error("任务 {} 完成，耗时： {} ms", currentIndex, endTime - startTime);
                } catch (Exception e) {
                    log.error("任务 {} 失败： {}", currentIndex, e.getMessage());
                }
            });
        }

        threadPool.shutdown();

    }

    // 初始化用户和快递员
    private void InitUserAndCourier(ArrayList<String> userList, ArrayList<String> courierList) {
        // 注册用户
        for (String s : userList) {
            DeliveryUserRegisterInputBO userRegisterInputBO = new DeliveryUserRegisterInputBO();
            userRegisterInputBO.set_userAddress(s);
            try {
                deliveryService.userRegister(userRegisterInputBO);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        // 注册快递员
        for (String s : courierList) {
            DeliveryCourierRegisterInputBO courierRegisterInputBO = new DeliveryCourierRegisterInputBO();
            courierRegisterInputBO.set_courierAddress(s);
            try {
                deliveryService.courierRegister(courierRegisterInputBO);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    // 初始化用户地址
    private ArrayList<String> initUserAddress() {
        ArrayList<String> userAddressList = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            CryptoSuite cryptoSuite = new CryptoSuite(CryptoType.ECDSA_TYPE);
            CryptoKeyPair keyPair = cryptoSuite.createKeyPair();
            userAddressList.add(keyPair.getAddress());
        }
        return userAddressList;
    }
}
