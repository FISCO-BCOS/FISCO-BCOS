package com.example.delivery.service;

import com.example.delivery.model.bo.ParallelContractRegisterParallelFunctionInputBO;
import com.example.delivery.model.bo.ParallelContractUnregisterParallelFunctionInputBO;
import java.lang.Exception;
import java.lang.String;
import java.util.Arrays;
import javax.annotation.PostConstruct;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@NoArgsConstructor
@Data
public class ParallelContractService {
  public static final String ABI = com.example.delivery.utils.IOUtil.readResourceAsString("abi/ParallelContract.abi");

  public static final String BINARY = com.example.delivery.utils.IOUtil.readResourceAsString("bin/ecc/ParallelContract.bin");

  public static final String SM_BINARY = com.example.delivery.utils.IOUtil.readResourceAsString("bin/sm/ParallelContract.bin");

  @Value("${system.contract.parallelContractAddress}")
  private String address;

  @Autowired
  private Client client;

  AssembleTransactionProcessor txProcessor;

  @PostConstruct
  public void init() throws Exception {
    this.txProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(this.client, this.client.getCryptoSuite().getCryptoKeyPair());
  }

  public TransactionResponse registerParallelFunction(ParallelContractRegisterParallelFunctionInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "registerParallelFunction", input.toArgs());
  }

  public TransactionResponse enableParallel() throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "enableParallel", Arrays.asList());
  }

  public TransactionResponse unregisterParallelFunction(ParallelContractUnregisterParallelFunctionInputBO input) throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "unregisterParallelFunction", input.toArgs());
  }

  public TransactionResponse disableParallel() throws Exception {
    return this.txProcessor.sendTransactionAndGetResponse(this.address, ABI, "disableParallel", Arrays.asList());
  }
}
