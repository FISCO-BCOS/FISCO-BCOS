package com.example.delivery.config;

import java.lang.String;
import lombok.Data;

@Data
public class ContractConfig {
  private String parallelContractAddress;

  private String deliveryAddress;

  private String storageDataAddress;
}
