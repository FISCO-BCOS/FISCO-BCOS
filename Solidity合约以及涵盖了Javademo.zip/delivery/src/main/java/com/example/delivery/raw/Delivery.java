import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.fisco.bcos.sdk.abi.FunctionReturnDecoder;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Address;
import org.fisco.bcos.sdk.abi.datatypes.Bool;
import org.fisco.bcos.sdk.abi.datatypes.DynamicArray;
import org.fisco.bcos.sdk.abi.datatypes.DynamicStruct;
import org.fisco.bcos.sdk.abi.datatypes.Event;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.Utf8String;
import org.fisco.bcos.sdk.abi.datatypes.generated.Uint256;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple1;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple2;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple3;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple4;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.eventsub.EventCallback;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.model.callback.TransactionCallback;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class Delivery extends Contract {
    public static final String[] BINARY_ARRAY = {"6080604052611006600660006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff16021790555034801561005357600080fd5b5061008073871c15e058f81906e9b7faea37b0023a3a13fdc6610109640100000000026401000000009004565b6100ac73081ae64bb3e2d480b6dfd5b994451420ee58830e610109640100000000026401000000009004565b6100d873442234617ffb5e26892a8e329f42cf23dd9a0ff96101d5640100000000026401000000009004565b61010473c3990fe75c7b2354b80fa0a90bb3cd75441011686101d5640100000000026401000000009004565b6102a1565b80600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060000160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055506001600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206001018190555050565b80600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060000160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055506002600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206001018190555050565b6115ca80620002b16000396000f3006080604052600436106100db576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff168063058d3fd9146100e0578063179e99971461010b5780632143ef681461013457806331c02c111461017457806334a18dda146101b25780634cc8e401146101db578063531625581461020457806367df94d71461022d57806371806147146102565780637278ee971461029357806379fa913f146102d057806393697553146102f95780639bc5178314610324578063bca926af14610361578063d39f70bc14610378575b600080fd5b3480156100ec57600080fd5b506100f561038f565b60405161010291906113ea565b60405180910390f35b34801561011757600080fd5b50610132600480360361012d9190810190610fe3565b610395565b005b34801561014057600080fd5b5061015b6004803603610156919081019061112c565b61065c565b60405161016b9493929190611405565b60405180910390f35b34801561018057600080fd5b5061019b60048036036101969190810190610fba565b6106cc565b6040516101a9929190611344565b60405180910390f35b3480156101be57600080fd5b506101d960048036036101d491908101906110d8565b610710565b005b3480156101e757600080fd5b5061020260048036036101fd9190810190610fba565b6107e2565b005b34801561021057600080fd5b5061022b60048036036102269190810190610fba565b6108ae565b005b34801561023957600080fd5b50610254600480360361024f9190810190611032565b61097a565b005b34801561026257600080fd5b5061027d6004803603610278919081019061112c565b610ad2565b60405161028a91906113ea565b60405180910390f35b34801561029f57600080fd5b506102ba60048036036102b59190810190610fba565b610af5565b6040516102c7919061138f565b60405180910390f35b3480156102dc57600080fd5b506102f760048036036102f29190810190611097565b610b15565b005b34801561030557600080fd5b5061030e610be4565b60405161031b919061136d565b60405180910390f35b34801561033057600080fd5b5061034b60048036036103469190810190610fba565b610d65565b604051610358919061138f565b60405180910390f35b34801561036d57600080fd5b50610376610d85565b005b34801561038457600080fd5b5061038d610e2e565b005b60005481565b6000836002600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206001015414151561041f576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610416906113aa565b60405180910390fd5b6000808154809291906001019190505550600560008054815260200190815260200160002091506000548260000181905550848260010160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550838260020160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550428260030181905550600160005490806001815401808255809150509060018203906000526020600020016000909192909190915055506000831415610574576001600260008673ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff021916908315150217905550610611565b6000600260008673ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff021916908315150217905550428573ffffffffffffffffffffffffffffffffffffffff167f327b0896c608e68e4e82de1aa97c33539ccad7fc7d66273a11e24f785ad361f460405160405180910390a35b828473ffffffffffffffffffffffffffffffffffffffff167ff4b7ab5b8fc49d6d35d323cae6a96e1441b461f862dfc5aff92e806e2839b5b060405160405180910390a35050505050565b60056020528060005260406000206000915090508060000154908060010160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16908060020160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16908060030154905084565b60046020528060005260406000206000915090508060000160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16908060010154905082565b600660009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16630553904e3084846040518463ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040161078b93929190611306565b602060405180830381600087803b1580156107a557600080fd5b505af11580156107b9573d6000803e3d6000fd5b505050506040513d601f19601f820116820180604052506107dd919081019061106e565b505050565b80600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060000160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055506002600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206001018190555050565b80600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060000160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055506001600460008373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019081526020016000206001018190555050565b60001515600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff161515141515610a0f576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401610a06906113ca565b60405180910390fd5b6000811415610a75576001600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff021916908315150217905550610ace565b6000600360008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055505b5050565b600181815481101515610ae157fe5b906000526020600020016000915090505481565b60026020528060005260406000206000915054906101000a900460ff1681565b600660009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166311e3f2af30836040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401610b8e9291906112d6565b602060405180830381600087803b158015610ba857600080fd5b505af1158015610bbc573d6000803e3d6000fd5b505050506040513d601f19601f82011682018060405250610be0919081019061106e565b5050565b6060806000600180549050604051908082528060200260200182016040528015610c2857816020015b610c15610ed3565b815260200190600190039081610c0d5790505b509150600090505b600180549050811015610d5d5760056000600183815481101515610c5057fe5b9060005260206000200154815260200190815260200160002060806040519081016040529081600082015481526020016001820160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020016002820160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020016003820154815250508282815181101515610d4357fe5b9060200190602002018190","52508080600101915050610c30565b819250505090565b60036020528060005260406000206000915054906101000a900460ff1681565b610dec606060405190810160405280602a81526020017f636f7572696572546f557365725369676e28616464726573732c61646472657381526020017f732c75696e7432353629000000000000000000000000000000000000000000008152506002610710565b610e2c6040805190810160405280601b81526020017f616674657253616c657328616464726573732c75696e743235362900000000008152506001610710565b565b610e93606060405190810160405280602781526020017f636f7572696572546f557365725369676e28616464726573732c61646472657381526020017f732c626f6f6c2900000000000000000000000000000000000000000000000000815250610b15565b610ed16040805190810160405280601b81526020017f616674657253616c657328616464726573732c75696e74323536290000000000815250610b15565b565b60806040519081016040528060008152602001600073ffffffffffffffffffffffffffffffffffffffff168152602001600073ffffffffffffffffffffffffffffffffffffffff168152602001600081525090565b6000610f348235611509565b905092915050565b6000610f488251611529565b905092915050565b600082601f8301121515610f6357600080fd5b8135610f76610f7182611477565b61144a565b91508082526020830160208301858383011115610f9257600080fd5b610f9d83828461153d565b50505092915050565b6000610fb28235611533565b905092915050565b600060208284031215610fcc57600080fd5b6000610fda84828501610f28565b91505092915050565b600080600060608486031215610ff857600080fd5b600061100686828701610f28565b935050602061101786828701610f28565b925050604061102886828701610fa6565b9150509250925092565b6000806040838503121561104557600080fd5b600061105385828601610f28565b925050602061106485828601610fa6565b9150509250929050565b60006020828403121561108057600080fd5b600061108e84828501610f3c565b91505092915050565b6000602082840312156110a957600080fd5b600082013567ffffffffffffffff8111156110c357600080fd5b6110cf84828501610f50565b91505092915050565b600080604083850312156110eb57600080fd5b600083013567ffffffffffffffff81111561110557600080fd5b61111185828601610f50565b925050602061112285828601610fa6565b9150509250929050565b60006020828403121561113e57600080fd5b600061114c84828501610fa6565b91505092915050565b61115e816114d3565b82525050565b600061116f826114b0565b808452602084019350611181836114a3565b60005b828110156111b357611197868351611272565b6111a0826114c6565b9150608086019550600181019050611184565b50849250505092915050565b6111c8816114f3565b82525050565b60006111d9826114bb565b8084526111ed81602086016020860161154c565b6111f68161157f565b602085010191505092915050565b6000601b82527fe5bd93e5898de794a8e688b7e4b88de698afe5bfabe98092e5919800000000006020830152604082019050919050565b6000601e82527fe5bd93e5898de794a8e688b7e5b7b2e7bb8fe794b3e8afb7e594aee5908e00006020830152604082019050919050565b60808201600082015161128860008501826112c7565b50602082015161129b6020850182611155565b5060408201516112ae6040850182611155565b5060608201516112c160608501826112c7565b50505050565b6112d0816114ff565b82525050565b60006040820190506112eb6000830185611155565b81810360208301526112fd81846111ce565b90509392505050565b600060608201905061131b6000830186611155565b818103602083015261132d81856111ce565b905061133c60408301846112c7565b949350505050565b60006040820190506113596000830185611155565b61136660208301846112c7565b9392505050565b600060208201905081810360008301526113878184611164565b905092915050565b60006020820190506113a460008301846111bf565b92915050565b600060208201905081810360008301526113c381611204565b9050919050565b600060208201905081810360008301526113e38161123b565b9050919050565b60006020820190506113ff60008301846112c7565b92915050565b600060808201905061141a60008301876112c7565b6114276020830186611155565b6114346040830185611155565b61144160608301846112c7565b95945050505050565b6000604051905081810181811067ffffffffffffffff8211171561146d57600080fd5b8060405250919050565b600067ffffffffffffffff82111561148e57600080fd5b601f19601f8301169050602081019050919050565b6000602082019050919050565b600081519050919050565b600081519050919050565b6000602082019050919050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b60008115159050919050565b6000819050919050565b600073ffffffffffffffffffffffffffffffffffffffff82169050919050565b6000819050919050565b6000819050919050565b82818337600083830152505050565b60005b8381101561156a57808201518184015260208101905061154f565b83811115611579576000848401525b50505050565b6000601f19601f83011690509190505600a265627a7a72305820edbf54f39f83e7ae32ea12a14602fa522c2a288582926493f9d0e6d50d6729f56c6578706572696d656e74616cf50037"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":true,\"inputs\":[],\"name\":\"RecordCount\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_from\",\"type\":\"address\"},{\"name\":\"_to\",\"type\":\"address\"},{\"name\":\"_isSign\",\"type\":\"uint256\"}],\"name\":\"courierToUserSign\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"RecordMap\",\"outputs\":[{\"name\":\"record_id\",\"type\":\"uint256\"},{\"name\":\"c_address\",\"type\":\"address\"},{\"name\":\"u_address\",\"type\":\"address\"},{\"name\":\"sign_time\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"UserMap\",\"outputs\":[{\"name\":\"u_address\",\"type\":\"address\"},{\"name\":\"role\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"functionName\",\"type\":\"string\"},{\"name\":\"criticalSize\",\"type\":\"uint256\"}],\"name\":\"registerParallelFunction\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_courierAddress\",\"type\":\"address\"}],\"name\":\"courierRegister\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_userAddress\",\"type\":\"address\"}],\"name\":\"userRegister\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_from\",\"type\":\"address\"},{\"name\":\"_isClaim\",\"type\":\"uint256\"}],\"name\":\"afterSales\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"SignRecordList\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"UserIsSignStatus\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"functionName\",\"type\":\"string\"}],\"name\":\"unregisterParallelFunction\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"selectSignRecordList\",\"outputs\":[{\"components\":[{\"name\":\"record_id\",\"type\":\"uint256\"},{\"name\":\"c_address\",\"type\":\"address\"},{\"name\":\"u_address\",\"type\":\"address\"},{\"name\":\"sign_time\",\"type\":\"uint256\"}],\"name\":\"\",\"type\":\"tuple[]\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"UserIsClaimStatus\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"enableParallel\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"disableParallel\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"_userAddress\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"_role\",\"type\":\"uint256\"}],\"name\":\"Registered\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"_userAddress\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"_isSign\",\"type\":\"uint256\"}],\"name\":\"Signed\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"_userAddress\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"_time\",\"type\":\"uint256\"}],\"name\":\"Refusal\",\"type\":\"event\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC_RECORDCOUNT = "RecordCount";

    public static final String FUNC_COURIERTOUSERSIGN = "courierToUserSign";

    public static final String FUNC_RECORDMAP = "RecordMap";

    public static final String FUNC_USERMAP = "UserMap";

    public static final String FUNC_REGISTERPARALLELFUNCTION = "registerParallelFunction";

    public static final String FUNC_COURIERREGISTER = "courierRegister";

    public static final String FUNC_USERREGISTER = "userRegister";

    public static final String FUNC_AFTERSALES = "afterSales";

    public static final String FUNC_SIGNRECORDLIST = "SignRecordList";

    public static final String FUNC_USERISSIGNSTATUS = "UserIsSignStatus";

    public static final String FUNC_UNREGISTERPARALLELFUNCTION = "unregisterParallelFunction";

    public static final String FUNC_SELECTSIGNRECORDLIST = "selectSignRecordList";

    public static final String FUNC_USERISCLAIMSTATUS = "UserIsClaimStatus";

    public static final String FUNC_ENABLEPARALLEL = "enableParallel";

    public static final String FUNC_DISABLEPARALLEL = "disableParallel";

    public static final Event REGISTERED_EVENT = new Event("Registered", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Uint256>(true) {}));
    ;

    public static final Event SIGNED_EVENT = new Event("Signed", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Uint256>(true) {}));
    ;

    public static final Event REFUSAL_EVENT = new Event("Refusal", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Uint256>(true) {}));
    ;

    protected Delivery(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public BigInteger RecordCount() throws ContractException {
        final Function function = new Function(FUNC_RECORDCOUNT, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeCallWithSingleValueReturn(function, BigInteger.class);
    }

    public TransactionReceipt courierToUserSign(String _from, String _to, BigInteger _isSign) {
        final Function function = new Function(
                FUNC_COURIERTOUSERSIGN, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_from), 
                new org.fisco.bcos.sdk.abi.datatypes.Address(_to), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_isSign)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] courierToUserSign(String _from, String _to, BigInteger _isSign, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_COURIERTOUSERSIGN, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_from), 
                new org.fisco.bcos.sdk.abi.datatypes.Address(_to), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_isSign)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForCourierToUserSign(String _from, String _to, BigInteger _isSign) {
        final Function function = new Function(
                FUNC_COURIERTOUSERSIGN, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_from), 
                new org.fisco.bcos.sdk.abi.datatypes.Address(_to), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_isSign)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple3<String, String, BigInteger> getCourierToUserSignInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_COURIERTOUSERSIGN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}, new TypeReference<Address>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple3<String, String, BigInteger>(

                (String) results.get(0).getValue(), 
                (String) results.get(1).getValue(), 
                (BigInteger) results.get(2).getValue()
                );
    }

    public Tuple4<BigInteger, String, String, BigInteger> RecordMap(BigInteger param0) throws ContractException {
        final Function function = new Function(FUNC_RECORDMAP, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Address>() {}, new TypeReference<Address>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple4<BigInteger, String, String, BigInteger>(
                (BigInteger) results.get(0).getValue(), 
                (String) results.get(1).getValue(), 
                (String) results.get(2).getValue(), 
                (BigInteger) results.get(3).getValue());
    }

    public Tuple2<String, BigInteger> UserMap(String param0) throws ContractException {
        final Function function = new Function(FUNC_USERMAP, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple2<String, BigInteger>(
                (String) results.get(0).getValue(), 
                (BigInteger) results.get(1).getValue());
    }

    public TransactionReceipt registerParallelFunction(String functionName, BigInteger criticalSize) {
        final Function function = new Function(
                FUNC_REGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(functionName), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(criticalSize)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] registerParallelFunction(String functionName, BigInteger criticalSize, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_REGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(functionName), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(criticalSize)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForRegisterParallelFunction(String functionName, BigInteger criticalSize) {
        final Function function = new Function(
                FUNC_REGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(functionName), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(criticalSize)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple2<String, BigInteger> getRegisterParallelFunctionInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_REGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple2<String, BigInteger>(

                (String) results.get(0).getValue(), 
                (BigInteger) results.get(1).getValue()
                );
    }

    public TransactionReceipt courierRegister(String _courierAddress) {
        final Function function = new Function(
                FUNC_COURIERREGISTER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_courierAddress)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] courierRegister(String _courierAddress, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_COURIERREGISTER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_courierAddress)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForCourierRegister(String _courierAddress) {
        final Function function = new Function(
                FUNC_COURIERREGISTER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_courierAddress)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getCourierRegisterInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_COURIERREGISTER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public TransactionReceipt userRegister(String _userAddress) {
        final Function function = new Function(
                FUNC_USERREGISTER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_userAddress)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] userRegister(String _userAddress, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_USERREGISTER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_userAddress)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForUserRegister(String _userAddress) {
        final Function function = new Function(
                FUNC_USERREGISTER, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_userAddress)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getUserRegisterInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_USERREGISTER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public TransactionReceipt afterSales(String _from, BigInteger _isClaim) {
        final Function function = new Function(
                FUNC_AFTERSALES, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_from), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_isClaim)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] afterSales(String _from, BigInteger _isClaim, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_AFTERSALES, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_from), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_isClaim)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForAfterSales(String _from, BigInteger _isClaim) {
        final Function function = new Function(
                FUNC_AFTERSALES, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(_from), 
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_isClaim)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple2<String, BigInteger> getAfterSalesInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_AFTERSALES, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple2<String, BigInteger>(

                (String) results.get(0).getValue(), 
                (BigInteger) results.get(1).getValue()
                );
    }

    public BigInteger SignRecordList(BigInteger param0) throws ContractException {
        final Function function = new Function(FUNC_SIGNRECORDLIST, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeCallWithSingleValueReturn(function, BigInteger.class);
    }

    public Boolean UserIsSignStatus(String param0) throws ContractException {
        final Function function = new Function(FUNC_USERISSIGNSTATUS, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeCallWithSingleValueReturn(function, Boolean.class);
    }

    public TransactionReceipt unregisterParallelFunction(String functionName) {
        final Function function = new Function(
                FUNC_UNREGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(functionName)), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] unregisterParallelFunction(String functionName, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_UNREGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(functionName)), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForUnregisterParallelFunction(String functionName) {
        final Function function = new Function(
                FUNC_UNREGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(functionName)), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<String> getUnregisterParallelFunctionInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_UNREGISTERPARALLELFUNCTION, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public TransactionReceipt selectSignRecordList() {
        final Function function = new Function(
                FUNC_SELECTSIGNRECORDLIST, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] selectSignRecordList(TransactionCallback callback) {
        final Function function = new Function(
                FUNC_SELECTSIGNRECORDLIST, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForSelectSignRecordList() {
        final Function function = new Function(
                FUNC_SELECTSIGNRECORDLIST, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple1<DynamicArray<Struct0>> getSelectSignRecordListOutput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getOutput();
        final Function function = new Function(FUNC_SELECTSIGNRECORDLIST, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<DynamicArray<Struct0>>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<DynamicArray<Struct0>>(

                (DynamicArray<Struct0>) results.get(0)
                );
    }

    public Boolean UserIsClaimStatus(String param0) throws ContractException {
        final Function function = new Function(FUNC_USERISCLAIMSTATUS, 
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Address(param0)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeCallWithSingleValueReturn(function, Boolean.class);
    }

    public TransactionReceipt enableParallel() {
        final Function function = new Function(
                FUNC_ENABLEPARALLEL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] enableParallel(TransactionCallback callback) {
        final Function function = new Function(
                FUNC_ENABLEPARALLEL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForEnableParallel() {
        final Function function = new Function(
                FUNC_ENABLEPARALLEL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public TransactionReceipt disableParallel() {
        final Function function = new Function(
                FUNC_DISABLEPARALLEL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public byte[] disableParallel(TransactionCallback callback) {
        final Function function = new Function(
                FUNC_DISABLEPARALLEL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return asyncExecuteTransaction(function, callback);
    }

    public String getSignedTransactionForDisableParallel() {
        final Function function = new Function(
                FUNC_DISABLEPARALLEL, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public List<RegisteredEventResponse> getRegisteredEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(REGISTERED_EVENT, transactionReceipt);
        ArrayList<RegisteredEventResponse> responses = new ArrayList<RegisteredEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            RegisteredEventResponse typedResponse = new RegisteredEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._userAddress = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._role = (BigInteger) eventValues.getIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeRegisteredEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(REGISTERED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeRegisteredEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(REGISTERED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public List<SignedEventResponse> getSignedEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(SIGNED_EVENT, transactionReceipt);
        ArrayList<SignedEventResponse> responses = new ArrayList<SignedEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            SignedEventResponse typedResponse = new SignedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._userAddress = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._isSign = (BigInteger) eventValues.getIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeSignedEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(SIGNED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeSignedEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(SIGNED_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public List<RefusalEventResponse> getRefusalEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(REFUSAL_EVENT, transactionReceipt);
        ArrayList<RefusalEventResponse> responses = new ArrayList<RefusalEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            RefusalEventResponse typedResponse = new RefusalEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._userAddress = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse._time = (BigInteger) eventValues.getIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public void subscribeRefusalEvent(String fromBlock, String toBlock, List<String> otherTopics, EventCallback callback) {
        String topic0 = eventEncoder.encode(REFUSAL_EVENT);
        subscribeEvent(ABI,BINARY,topic0,fromBlock,toBlock,otherTopics,callback);
    }

    public void subscribeRefusalEvent(EventCallback callback) {
        String topic0 = eventEncoder.encode(REFUSAL_EVENT);
        subscribeEvent(ABI,BINARY,topic0,callback);
    }

    public static Delivery load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new Delivery(contractAddress, client, credential);
    }

    public static Delivery deploy(Client client, CryptoKeyPair credential) throws ContractException {
        return deploy(Delivery.class, client, credential, getBinary(client.getCryptoSuite()), "");
    }

    public static class Struct0 extends DynamicStruct {
        public BigInteger record_id;

        public String c_address;

        public String u_address;

        public BigInteger sign_time;

        public Struct0(Uint256 record_id, Address c_address, Address u_address, Uint256 sign_time) {
            super(record_id,c_address,u_address,sign_time);
            this.record_id = record_id.getValue();
            this.c_address = c_address.getValue();
            this.u_address = u_address.getValue();
            this.sign_time = sign_time.getValue();
        }

        public Struct0(BigInteger record_id, String c_address, String u_address, BigInteger sign_time) {
            super(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(record_id),new org.fisco.bcos.sdk.abi.datatypes.Address(c_address),new org.fisco.bcos.sdk.abi.datatypes.Address(u_address),new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(sign_time));
            this.record_id = record_id;
            this.c_address = c_address;
            this.u_address = u_address;
            this.sign_time = sign_time;
        }
    }

    public static class RegisteredEventResponse {
        public TransactionReceipt.Logs log;

        public String _userAddress;

        public BigInteger _role;
    }

    public static class SignedEventResponse {
        public TransactionReceipt.Logs log;

        public String _userAddress;

        public BigInteger _isSign;
    }

    public static class RefusalEventResponse {
        public TransactionReceipt.Logs log;

        public String _userAddress;

        public BigInteger _time;
    }
}
