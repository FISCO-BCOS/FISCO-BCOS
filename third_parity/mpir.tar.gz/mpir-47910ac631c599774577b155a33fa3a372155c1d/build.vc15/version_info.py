﻿
# returns: 
#   solution file version
#   visual studio version
#   microsoft compiler version
#   microsoft compiler version (long)
#   vcx project tools version
vs_info = { 'solution':'12',
            'visual studio':'15',
            'msvc':'15',
            'msvc_long':'15.0',
            'vcx_tool':'15.0.25914.0',
            'platform_toolset':'141'
          }
