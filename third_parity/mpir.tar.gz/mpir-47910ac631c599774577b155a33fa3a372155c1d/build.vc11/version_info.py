﻿
# returns:
#   solution file version
#   visual studio version
#   microsoft compiler version
#   microsoft compiler version (long)
#   vcx project tools version
vs_info = { 'solution':'12',
            'visual studio':'2012',
            'msvc':'11',
            'msvc_long':'11',
            'vcx_tool':'4.0',
            'platform_toolset':'110'
          }
