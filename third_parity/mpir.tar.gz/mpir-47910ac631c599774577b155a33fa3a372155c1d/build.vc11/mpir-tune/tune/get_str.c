#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\mpn\generic\get_str.c"
