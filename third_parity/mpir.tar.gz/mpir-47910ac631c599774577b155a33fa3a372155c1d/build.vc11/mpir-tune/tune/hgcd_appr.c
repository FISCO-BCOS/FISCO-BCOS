#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\mpn\generic\hgcd_appr.c"
