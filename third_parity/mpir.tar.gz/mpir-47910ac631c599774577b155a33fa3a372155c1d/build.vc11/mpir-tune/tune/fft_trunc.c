#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\fft\fft_trunc.c"
