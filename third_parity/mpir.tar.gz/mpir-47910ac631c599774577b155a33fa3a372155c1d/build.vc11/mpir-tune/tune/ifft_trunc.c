#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\fft\ifft_trunc.c"
