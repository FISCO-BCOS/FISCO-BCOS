#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\mpn\generic\mulmod_2expm1.c"
