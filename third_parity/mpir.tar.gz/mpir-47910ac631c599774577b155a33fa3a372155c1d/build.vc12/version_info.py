﻿
# returns:
#   solution file version
#   visual studio version
#   microsoft compiler version
#   microsoft compiler version (long)
#   vcx project tools version
vs_info = { 'solution':'12',
            'visual studio':'2013',
            'msvc':'12',
            'msvc_long':'12.0.20827.3',
            'vcx_tool':'12.0',
            'platform_toolset':'120'
          }
